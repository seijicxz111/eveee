import './globals.css'
import { Daruma_Drop_One, Space_Mono } from 'next/font/google'

const daruma = Daruma_Drop_One({
  subsets: ['latin'],
  weight: ['400'],
  variable: '--font-daruma',
})

const spaceMono = Space_Mono({
  subsets: ['latin'],
  weight: ['400', '700'],
  variable: '--font-space',
})

export const metadata = {
  title: 'eeve',
  description: 'CJ Steeve Cadenas — Web Developer & UI Designer.',
}

export default function RootLayout({ children }) {
  return (
    <html
      lang="en"
      className={`${daruma.variable} ${spaceMono.variable}`}
    >
      <body>{children}</body>
    </html>
  )
}