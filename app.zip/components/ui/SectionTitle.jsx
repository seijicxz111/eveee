'use client';

import { useRef } from 'react';
import { motion, useInView } from 'framer-motion';

export default function SectionTitle({ emoji, title, sub }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : {}}
      transition={{ type: 'spring', stiffness: 260, damping: 22 }}
      className="text-center mb-4"
    >
      <div className="inline-flex items-center gap-3 mb-2">
        <span className="text-3xl">{emoji}</span>
        <h2 className="font-display font-800 text-4xl text-deep">{title}</h2>
        <span className="text-3xl">{emoji}</span>
      </div>

      {/* Decorative line */}
      <div className="flex items-center justify-center gap-3 mb-3">
        <span className="h-px w-12 bg-sky/40 rounded-full" />
        <span className="text-sky text-base">✿</span>
        <span className="h-px w-12 bg-sky/40 rounded-full" />
      </div>

      {sub && (
        <p className="text-deep/50 font-body text-sm">{sub}</p>
      )}
    </motion.div>
  );
}
