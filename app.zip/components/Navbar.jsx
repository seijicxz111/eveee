'use client';

import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const NAV_LINKS = [
  { href: '#about',     label: 'About'     },
  { href: '#skills',    label: 'Skills'    },
  { href: '#projects',  label: 'Projects'  },
  { href: '#education', label: 'Education' },
  { href: '#contact',   label: 'Contact'   },
];

const ChiikawaLogo = () => (
  <svg width="36" height="36" viewBox="0 0 36 36" fill="none">
    {/* cute round head */}
    <circle cx="18" cy="18" r="15" fill="#F7F8F0" stroke="#7AAACE" strokeWidth="2"/>
    {/* ears */}
    <ellipse cx="10" cy="8" rx="4" ry="5" fill="#F7F8F0" stroke="#7AAACE" strokeWidth="1.5"/>
    <ellipse cx="26" cy="8" rx="4" ry="5" fill="#F7F8F0" stroke="#7AAACE" strokeWidth="1.5"/>
    {/* inner ears */}
    <ellipse cx="10" cy="8" rx="2" ry="3" fill="#F9C5D1"/>
    <ellipse cx="26" cy="8" rx="2" ry="3" fill="#F9C5D1"/>
    {/* eyes */}
    <circle cx="14" cy="19" r="2.5" fill="#355872"/>
    <circle cx="22" cy="19" r="2.5" fill="#355872"/>
    <circle cx="14.8" cy="18.2" r="0.8" fill="white"/>
    <circle cx="22.8" cy="18.2" r="0.8" fill="white"/>
    {/* blush */}
    <ellipse cx="11.5" cy="22" rx="2.5" ry="1.2" fill="#F9C5D1" opacity="0.7"/>
    <ellipse cx="24.5" cy="22" rx="2.5" ry="1.2" fill="#F9C5D1" opacity="0.7"/>
    {/* mouth */}
    <path d="M15.5 24 Q18 26.5 20.5 24" stroke="#355872" strokeWidth="1.2" fill="none" strokeLinecap="round"/>
  </svg>
);

export default function Navbar() {
  const [scrolled,     setScrolled]     = useState(false);
  const [activeSection, setActive]      = useState('about');
  const [mobileOpen,   setMobileOpen]   = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 20);

      // active section detection
      const sections = NAV_LINKS.map(l => l.href.slice(1));
      let current = 'about';
      for (const id of sections) {
        const el = document.getElementById(id);
        if (el && window.scrollY >= el.offsetTop - 120) current = id;
      }
      setActive(current);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleNavClick = (href) => {
    setMobileOpen(false);
    document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <motion.nav
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0,   opacity: 1 }}
      transition={{ duration: 0.6, ease: [0.34,1.56,0.64,1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/85 backdrop-blur-xl border-b border-sky/30 shadow-chiikawa'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-6xl mx-auto px-5 py-3 flex items-center justify-between">
        {/* Logo */}
        <motion.button
          onClick={() => handleNavClick('#about')}
          className="flex items-center gap-2.5 group"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <ChiikawaLogo />
          <span className="font-display font-800 text-deep text-lg leading-none">
            Seijicxz
          </span>
        </motion.button>

        {/* Desktop links */}
        <div className="hidden md:flex items-center gap-1">
          {NAV_LINKS.map((link, i) => (
            <motion.button
              key={link.href}
              onClick={() => handleNavClick(link.href)}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.07 }}
              className={`relative px-4 py-2 rounded-full text-sm font-body font-700 transition-all duration-200 ${
                activeSection === link.href.slice(1)
                  ? 'bg-sky/25 text-deep'
                  : 'text-deep/60 hover:text-deep hover:bg-sky/15'
              }`}
            >
              {link.label}
              {activeSection === link.href.slice(1) && (
                <motion.span
                  layoutId="nav-indicator"
                  className="absolute inset-0 rounded-full bg-sky/20 border border-sky/40"
                  transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                />
              )}
            </motion.button>
          ))}
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMobileOpen(v => !v)}
          aria-label="Toggle menu"
        >
          {[0,1,2].map(i => (
            <motion.span
              key={i}
              className="block h-0.5 w-6 bg-deep rounded-full"
              animate={mobileOpen ? (
                i === 0 ? { rotate: 45, y: 8 } :
                i === 1 ? { opacity: 0 } :
                          { rotate: -45, y: -8 }
              ) : { rotate: 0, y: 0, opacity: 1 }}
              transition={{ duration: 0.2 }}
            />
          ))}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{  height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="md:hidden overflow-hidden bg-white/95 backdrop-blur-xl border-t border-sky/20"
          >
            <div className="px-5 py-4 flex flex-col gap-1">
              {NAV_LINKS.map(link => (
                <button
                  key={link.href}
                  onClick={() => handleNavClick(link.href)}
                  className={`text-left px-4 py-2.5 rounded-2xl font-body font-700 text-sm transition-all ${
                    activeSection === link.href.slice(1)
                      ? 'bg-sky/25 text-deep'
                      : 'text-deep/60 hover:bg-sky/15 hover:text-deep'
                  }`}
                >
                  {link.label}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}
