'use client';

import { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';

const ROLES = [
  'Web Developer',
  'UI Designer',
  'Aspiring Engineer',
  'Anime Enthusiast',
];

// Chiikawa SVG mascot inline
const ChiikawaMascot = ({ className }) => (
  <svg className={className} viewBox="0 0 200 220" fill="none" xmlns="http://www.w3.org/2000/svg">
    {/* Body */}
    <ellipse cx="100" cy="155" rx="52" ry="48" fill="white" stroke="#9CD5FF" strokeWidth="2.5"/>
    {/* Head */}
    <circle cx="100" cy="90" r="62" fill="white" stroke="#9CD5FF" strokeWidth="2.5"/>
    {/* Ears */}
    <ellipse cx="52" cy="44" rx="18" ry="24" fill="white" stroke="#9CD5FF" strokeWidth="2.5"/>
    <ellipse cx="148" cy="44" rx="18" ry="24" fill="white" stroke="#9CD5FF" strokeWidth="2.5"/>
    <ellipse cx="52" cy="44" rx="10" ry="15" fill="#F9C5D1"/>
    <ellipse cx="148" cy="44" rx="10" ry="15" fill="#F9C5D1"/>
    {/* Face shadow */}
    <ellipse cx="100" cy="100" rx="50" ry="38" fill="rgba(156,213,255,0.06)"/>
    {/* Eyes */}
    <circle cx="82" cy="88" r="11" fill="#355872"/>
    <circle cx="118" cy="88" r="11" fill="#355872"/>
    <circle cx="85" cy="84" r="4" fill="white"/>
    <circle cx="121" cy="84" r="4" fill="white"/>
    <circle cx="86.5" cy="82.5" r="2" fill="white"/>
    <circle cx="122.5" cy="82.5" r="2" fill="white"/>
    {/* Blush cheeks */}
    <ellipse cx="66" cy="102" rx="12" ry="6" fill="#F9C5D1" opacity="0.75"/>
    <ellipse cx="134" cy="102" rx="12" ry="6" fill="#F9C5D1" opacity="0.75"/>
    {/* Mouth */}
    <path d="M88 112 Q100 122 112 112" stroke="#355872" strokeWidth="2.5" fill="none" strokeLinecap="round"/>
    {/* Small nose */}
    <ellipse cx="100" cy="107" rx="3.5" ry="2.5" fill="#355872" opacity="0.5"/>
    {/* Arms */}
    <ellipse cx="52" cy="155" rx="18" ry="12" fill="white" stroke="#9CD5FF" strokeWidth="2" transform="rotate(-20 52 155)"/>
    <ellipse cx="148" cy="155" rx="18" ry="12" fill="white" stroke="#9CD5FF" strokeWidth="2" transform="rotate(20 148 155)"/>
    {/* Feet */}
    <ellipse cx="82" cy="198" rx="20" ry="12" fill="white" stroke="#9CD5FF" strokeWidth="2"/>
    <ellipse cx="118" cy="198" rx="20" ry="12" fill="white" stroke="#9CD5FF" strokeWidth="2"/>
    {/* Tiny paw dots */}
    <circle cx="76" cy="199" r="2.5" fill="#9CD5FF" opacity="0.6"/>
    <circle cx="83" cy="202" r="2.5" fill="#9CD5FF" opacity="0.6"/>
    <circle cx="90" cy="199" r="2.5" fill="#9CD5FF" opacity="0.6"/>
    <circle cx="112" cy="199" r="2.5" fill="#9CD5FF" opacity="0.6"/>
    <circle cx="119" cy="202" r="2.5" fill="#9CD5FF" opacity="0.6"/>
    <circle cx="126" cy="199" r="2.5" fill="#9CD5FF" opacity="0.6"/>
  </svg>
);

// Floating deco shapes
const FloatingShape = ({ type, style }) => {
  const shapes = {
    star:  '★', heart: '♥', flower: '✿',
    note:  '♪', cloud: '☁', paw: '🐾',
  };
  return (
    <motion.span
      className="absolute select-none pointer-events-none text-sky/40 font-bold"
      style={style}
      animate={{ y: [0, -14, 0], rotate: [0, 8, -5, 0] }}
      transition={{ duration: 5 + Math.random() * 3, repeat: Infinity, ease: 'easeInOut' }}
    >
      {shapes[type]}
    </motion.span>
  );
};

export default function Hero() {
  const [roleIdx, setRoleIdx] = useState(0);
  const [displayed, setDisplayed] = useState('');
  const [typing, setTyping] = useState(true);

  useEffect(() => {
    const target = ROLES[roleIdx];
    if (typing) {
      if (displayed.length < target.length) {
        const t = setTimeout(() => setDisplayed(target.slice(0, displayed.length + 1)), 80);
        return () => clearTimeout(t);
      } else {
        const t = setTimeout(() => setTyping(false), 1800);
        return () => clearTimeout(t);
      }
    } else {
      if (displayed.length > 0) {
        const t = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 45);
        return () => clearTimeout(t);
      } else {
        setRoleIdx(i => (i + 1) % ROLES.length);
        setTyping(true);
      }
    }
  }, [displayed, typing, roleIdx]);

  const container = {
    hidden: {},
    show: { transition: { staggerChildren: 0.12 } },
  };
  const item = {
    hidden: { opacity: 0, y: 30 },
    show:   { opacity: 1, y: 0, transition: { type: 'spring', stiffness: 260, damping: 20 } },
  };

  return (
    <section
      id="about"
      className="relative min-h-screen flex items-center pt-20 pb-16 overflow-hidden"
    >
      {/* Dot pattern */}
      <div className="absolute inset-0 dot-bg opacity-60 pointer-events-none" />

      {/* Floating decorations */}
      <FloatingShape type="star"   style={{ top: '12%', left: '6%', fontSize: '2.2rem', animationDelay: '0s' }} />
      <FloatingShape type="heart"  style={{ top: '20%', right: '8%', fontSize: '1.6rem', color: 'rgba(249,197,209,0.6)', animationDelay: '0.8s' }} />
      <FloatingShape type="flower" style={{ bottom: '20%', left: '4%', fontSize: '2rem',  animationDelay: '1.4s' }} />
      <FloatingShape type="note"   style={{ bottom: '30%', right: '5%', fontSize: '1.8rem', animationDelay: '0.4s' }} />
      <FloatingShape type="cloud"  style={{ top: '55%', left: '10%', fontSize: '1.4rem', animationDelay: '2s' }} />

      <div className="max-w-6xl mx-auto px-5 w-full relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Text side */}
          <motion.div
            variants={container}
            initial="hidden"
            animate="show"
            className="order-2 md:order-1"
          >
            <motion.div variants={item} className="flex items-center gap-3 mb-5">
              <span className="flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-sky/20 border border-sky/40 text-deep text-xs font-body font-800">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse-soft inline-block"/>
                Available for opportunities
              </span>
              <span className="text-deep/40 text-xs font-mono">Philippines 🇵🇭</span>
            </motion.div>

            <motion.p variants={item} className="text-mid font-display font-700 text-lg mb-1">
              Hello there! I&apos;m
            </motion.p>

            <motion.h1
              variants={item}
              className="font-display font-800 text-5xl md:text-6xl leading-none text-deep mb-3"
              style={{ letterSpacing: '-0.02em' }}
            >
              CJ Steeve
              <br />
              <span style={{ background: 'linear-gradient(135deg, #355872 0%, #7AAACE 60%, #9CD5FF 100%)', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text' }}>
                Cadenas
              </span>
            </motion.h1>

            <motion.div variants={item} className="flex items-center gap-2 mb-6 h-9">
              <span className="text-mid font-display font-700 text-xl">✦</span>
              <span className="font-display font-700 text-2xl text-deep">
                {displayed}
                <span className="typed-cursor">|</span>
              </span>
            </motion.div>

            <motion.p variants={item} className="text-deep/65 font-body text-base leading-relaxed max-w-md mb-8">
              Aspiring web developer & UI designer from the Philippines, passionate about crafting beautiful, accessible, and delightful digital experiences.
            </motion.p>

            <motion.div variants={item} className="flex flex-wrap gap-3 mb-8">
              <a
                href="#contact"
                className="btn-chiikawa btn-chiikawa-primary"
                onClick={e => { e.preventDefault(); document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' }); }}
              >
                <i className="fas fa-paper-plane text-xs" /> Say Hello
              </a>
              <a
                href="#projects"
                className="btn-chiikawa btn-chiikawa-secondary"
                onClick={e => { e.preventDefault(); document.querySelector('#projects')?.scrollIntoView({ behavior: 'smooth' }); }}
              >
                <i className="fas fa-folder-open text-xs" /> My Projects
              </a>
            </motion.div>

            {/* Social row */}
            <motion.div variants={item} className="flex items-center gap-3">
              {[
                { icon: 'fab fa-github',    href: 'https://github.com/seijicxz', label: 'GitHub' },
                { icon: 'fab fa-twitter',   href: '#', label: 'Twitter' },
                { icon: 'fab fa-linkedin',  href: '#', label: 'LinkedIn' },
              ].map(s => (
                <motion.a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={s.label}
                  className="w-11 h-11 rounded-full flex items-center justify-center bg-white border-2 border-sky/30 text-deep/60 hover:text-deep hover:border-mid hover:shadow-sky transition-all duration-200"
                  whileHover={{ y: -4, scale: 1.1 }}
                  whileTap={{ scale: 0.92 }}
                >
                  <i className={s.icon} />
                </motion.a>
              ))}
              <div className="h-6 w-px bg-sky/30 mx-1" />
              <span className="text-xs text-deep/40 font-body font-700">seijicxz</span>
            </motion.div>
          </motion.div>

          {/* Mascot side */}
          <motion.div
            initial={{ opacity: 0, scale: 0.7, rotate: -5 }}
            animate={{ opacity: 1, scale: 1,   rotate: 0 }}
            transition={{ delay: 0.3, type: 'spring', stiffness: 200, damping: 18 }}
            className="order-1 md:order-2 flex items-center justify-center"
          >
            <div className="relative">
              {/* Glow ring */}
              <motion.div
                className="absolute inset-[-20px] rounded-full border-2 border-sky/30"
                animate={{ scale: [1, 1.06, 1], opacity: [0.5, 0.2, 0.5] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut' }}
              />
              <motion.div
                className="absolute inset-[-38px] rounded-full border border-sky/15"
                animate={{ scale: [1, 1.08, 1], opacity: [0.3, 0.1, 0.3] }}
                transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.8 }}
              />

              {/* Profile image container */}
              <motion.div
                className="relative w-64 h-64 rounded-full overflow-hidden border-4 border-sky/40 shadow-chiikawa-lg bg-cream"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
              >
                <img
                  src="https://images.weserv.nl/?url=64.media.tumblr.com/ff21b4f05bb79f16e0dceb7dfad75272/tumblr_mqtho3Fr0n1rgam01o1_1280.png&w=320&h=320&output=webp&q=85"
                  alt="Profile"
                  className="w-full h-full object-cover"
                />
              </motion.div>

              {/* Chiikawa mascot badge */}
              <motion.div
                className="absolute -bottom-4 -right-4 bg-white rounded-2xl p-2 border-2 border-sky/40 shadow-chiikawa"
                animate={{ rotate: [0, 10, -6, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              >
                <ChiikawaMascot className="w-14 h-14" />
              </motion.div>

              {/* Floating skill badges */}
              {[
                { label: 'React',    icon: 'fab fa-react',   x: '-left-8', y: 'top-8',    delay: 0 },
                { label: 'Next.js',  icon: 'fas fa-code',    x: '-right-8', y: 'top-16',  delay: 0.5 },
                { label: 'Figma',    icon: 'fab fa-figma',   x: '-left-4', y: 'bottom-16', delay: 1 },
              ].map(b => (
                <motion.div
                  key={b.label}
                  className={`absolute ${b.x} ${b.y} bg-white rounded-2xl px-3 py-1.5 flex items-center gap-2 shadow-chiikawa border border-sky/30`}
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 3.5 + Number(b.delay), repeat: Infinity, ease: 'easeInOut', delay: b.delay }}
                >
                  <i className={`${b.icon} text-mid text-xs`} />
                  <span className="text-xs font-body font-800 text-deep">{b.label}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>

        {/* Scroll hint */}
        <motion.div
          className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-deep/30"
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
        >
          <span className="text-xs font-body font-700 tracking-widest">scroll</span>
          <i className="fas fa-chevron-down text-xs" />
        </motion.div>
      </div>

      {/* Wave bottom */}
      <div className="wave-divider absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1440 50" preserveAspectRatio="none">
          <path d="M0,30 C360,55 1080,5 1440,30 L1440,50 L0,50 Z" fill="rgba(156,213,255,0.08)"/>
        </svg>
      </div>
    </section>
  );
}
