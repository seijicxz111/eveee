'use client';

import { useState, useRef } from 'react';
import { motion, useInView, AnimatePresence } from 'framer-motion';
import SectionTitle from '@/components/ui/SectionTitle';

const SKILL_GROUPS = [
  {
    label: 'Frontend',
    icon: '🎨',
    skills: [
      { name: 'HTML & CSS',   level: 85, icon: 'fab fa-html5',    color: '#E96228' },
      { name: 'JavaScript',   level: 72, icon: 'fab fa-js-square', color: '#F0DB4F' },
      { name: 'React.js',     level: 68, icon: 'fab fa-react',     color: '#61DBFB' },
      { name: 'Tailwind CSS', level: 75, icon: 'fas fa-wind',      color: '#38BDF8' },
      { name: 'Next.js',      level: 55, icon: 'fas fa-code',      color: '#355872' },
    ],
  },
  {
    label: 'Backend',
    icon: '⚙️',
    skills: [
      { name: 'Node.js',    level: 55, icon: 'fab fa-node-js', color: '#83CD29' },
      { name: 'Python',     level: 50, icon: 'fab fa-python',  color: '#3572A5' },
      { name: 'Express.js', level: 50, icon: 'fas fa-server',  color: '#7AAACE' },
      { name: 'MySQL',      level: 48, icon: 'fas fa-database', color: '#00758F' },
    ],
  },
  {
    label: 'Tools',
    icon: '🛠️',
    skills: [
      { name: 'Git & GitHub', level: 75, icon: 'fab fa-github',  color: '#355872' },
      { name: 'Figma',        level: 70, icon: 'fab fa-figma',   color: '#A259FF' },
      { name: 'VS Code',      level: 88, icon: 'fas fa-code',    color: '#007ACC' },
      { name: 'Linux (WSL)',  level: 60, icon: 'fab fa-linux',   color: '#FCC624' },
    ],
  },
];

function SkillBar({ name, level, icon, color, delay = 0 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-40px' });

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, x: -20 }}
      animate={inView ? { opacity: 1, x: 0 } : {}}
      transition={{ delay, type: 'spring', stiffness: 260, damping: 22 }}
      className="flex items-center gap-4"
    >
      <div className="w-9 h-9 rounded-xl flex items-center justify-center bg-sky/10 border border-sky/20 flex-shrink-0">
        <i className={`${icon} text-sm`} style={{ color }} />
      </div>
      <div className="flex-1">
        <div className="flex justify-between mb-1.5">
          <span className="text-sm font-body font-700 text-deep">{name}</span>
          <span className="text-xs font-mono text-mid">{level}%</span>
        </div>
        <div className="skill-bar-track">
          <motion.div
            className="skill-bar-fill"
            initial={{ scaleX: 0 }}
            animate={inView ? { scaleX: level / 100 } : {}}
            transition={{ delay: delay + 0.15, duration: 1.1, ease: [0.25, 0.46, 0.45, 0.94] }}
          />
        </div>
      </div>
    </motion.div>
  );
}

export default function Skills() {
  const [active, setActive] = useState(0);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });

  return (
    <section id="skills" className="py-20 relative z-10" ref={ref}>
      <div className="max-w-4xl mx-auto px-5">
        <SectionTitle emoji="💡" title="Skills" sub="Technologies I work with" />

        {/* Tabs */}
        <div className="flex gap-2 justify-center flex-wrap mb-10">
          {SKILL_GROUPS.map((g, i) => (
            <motion.button
              key={g.label}
              onClick={() => setActive(i)}
              className={`flex items-center gap-2 px-5 py-2.5 rounded-full font-body font-800 text-sm transition-all duration-200 border-2 ${
                active === i
                  ? 'bg-deep text-white border-deep shadow-chiikawa'
                  : 'bg-white text-deep/60 border-sky/30 hover:border-mid hover:text-deep'
              }`}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <span>{g.icon}</span> {g.label}
            </motion.button>
          ))}
        </div>

        {/* Skills panel */}
        <AnimatePresence mode="wait">
          <motion.div
            key={active}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{   opacity: 0, y: -10 }}
            transition={{ duration: 0.25 }}
            className="chiikawa-card p-8"
          >
            <div className="flex items-center gap-3 mb-8">
              <span className="text-3xl">{SKILL_GROUPS[active].icon}</span>
              <div>
                <h3 className="font-display font-800 text-xl text-deep">{SKILL_GROUPS[active].label} Skills</h3>
                <p className="text-deep/45 text-xs font-body">My proficiency levels</p>
              </div>
            </div>
            <div className="space-y-5">
              {SKILL_GROUPS[active].skills.map((skill, i) => (
                <SkillBar key={skill.name} {...skill} delay={i * 0.08} />
              ))}
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Tech badge cloud */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ delay: 0.5 }}
          className="mt-8 flex flex-wrap gap-2.5 justify-center"
        >
          {['HTML', 'CSS', 'JavaScript', 'React', 'Next.js', 'Tailwind', 'Node.js', 'Python', 'Git', 'Figma', 'MySQL', 'VS Code'].map((t, i) => (
            <motion.span
              key={t}
              className="tag-pill"
              whileHover={{ scale: 1.1, y: -2 }}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ delay: 0.5 + i * 0.04 }}
            >
              {t}
            </motion.span>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
