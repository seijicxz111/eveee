'use client';

import { useState, useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import SectionTitle from '@/components/ui/SectionTitle';

const SOCIALS = [
  { icon: 'fab fa-github',    label: 'GitHub',    href: 'https://github.com/seijicxz',  value: 'seijicxz' },
  { icon: 'fab fa-twitter',   label: 'Twitter',   href: '#',                             value: '@seijicxz' },
  { icon: 'fab fa-linkedin',  label: 'LinkedIn',  href: '#',                             value: 'seijicxz' },
  { icon: 'fas fa-envelope',  label: 'Email',     href: 'mailto:hello@seijicxz.dev',     value: 'hello@seijicxz.dev', copyable: true },
];

export default function Contact() {
  const [form,     setForm]     = useState({ name: '', email: '', message: '' });
  const [status,   setStatus]   = useState('idle'); // idle | sending | sent | error
  const [copied,   setCopied]   = useState(null);
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: '-60px' });

  const handleChange = (e) => setForm(f => ({ ...f, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus('sending');
    // Simulate — replace with real form API (Formspree, EmailJS, etc.)
    await new Promise(r => setTimeout(r, 1500));
    setStatus('sent');
    setForm({ name: '', email: '', message: '' });
    setTimeout(() => setStatus('idle'), 4000);
  };

  const handleCopy = (text, label) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <section id="contact" className="py-20 relative z-10" ref={ref}>
      <div className="max-w-5xl mx-auto px-5">
        <SectionTitle emoji="💌" title="Contact" sub="Let's build something together" />

        <div className="grid md:grid-cols-5 gap-8 mt-10">
          {/* Left: info */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.15, type: 'spring', stiffness: 220, damping: 22 }}
            className="md:col-span-2 space-y-5"
          >
            <div className="chiikawa-card p-6">
              <h3 className="font-display font-800 text-deep text-lg mb-2">Say Hello! 👋</h3>
              <p className="text-deep/55 font-body text-sm leading-relaxed">
                I'm open to internship opportunities, freelance projects, and collaborations. Don't hesitate to reach out!
              </p>
            </div>

            <div className="space-y-3">
              {SOCIALS.map((s, i) => (
                <motion.div
                  key={s.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={inView ? { opacity: 1, x: 0 } : {}}
                  transition={{ delay: 0.2 + i * 0.07 }}
                  className="chiikawa-card p-4 flex items-center gap-3 group"
                >
                  <div className="w-10 h-10 rounded-xl bg-sky/15 border border-sky/25 flex items-center justify-center flex-shrink-0">
                    <i className={`${s.icon} text-mid text-sm`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-body font-700 text-deep/45">{s.label}</p>
                    <a
                      href={s.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-sm font-body font-700 text-deep hover:text-mid transition-colors truncate block"
                    >
                      {s.value}
                    </a>
                  </div>
                  {s.copyable && (
                    <button
                      onClick={() => handleCopy(s.href.replace('mailto:', ''), s.label)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center text-deep/35 hover:text-mid hover:bg-sky/15 transition-all"
                      aria-label="Copy email"
                    >
                      <i className={`fas ${copied === s.label ? 'fa-check text-emerald-500' : 'fa-copy'} text-xs`} />
                    </button>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: form */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ delay: 0.25, type: 'spring', stiffness: 220, damping: 22 }}
            className="md:col-span-3"
          >
            <div className="chiikawa-card p-8">
              <h3 className="font-display font-800 text-deep text-lg mb-6">Send a Message</h3>

              {status === 'sent' ? (
                <motion.div
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="text-center py-10"
                >
                  <div className="text-5xl mb-3">🎉</div>
                  <h4 className="font-display font-800 text-deep text-xl mb-2">Message sent!</h4>
                  <p className="text-deep/50 font-body text-sm">Thanks for reaching out. I'll get back to you soon~</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-body font-700 text-deep/60 mb-1.5">Name</label>
                      <input
                        name="name"
                        value={form.name}
                        onChange={handleChange}
                        required
                        placeholder="Your name"
                        className="chiikawa-input"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-body font-700 text-deep/60 mb-1.5">Email</label>
                      <input
                        name="email"
                        type="email"
                        value={form.email}
                        onChange={handleChange}
                        required
                        placeholder="your@email.com"
                        className="chiikawa-input"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-xs font-body font-700 text-deep/60 mb-1.5">Message</label>
                    <textarea
                      name="message"
                      value={form.message}
                      onChange={handleChange}
                      required
                      rows={5}
                      placeholder="What's on your mind?"
                      className="chiikawa-input"
                    />
                  </div>
                  <button
                    type="submit"
                    disabled={status === 'sending'}
                    className="btn-chiikawa btn-chiikawa-primary w-full"
                  >
                    {status === 'sending' ? (
                      <>
                        <i className="fas fa-circle-notch fa-spin text-xs" />
                        Sending…
                      </>
                    ) : (
                      <>
                        <i className="fas fa-paper-plane text-xs" />
                        Send Message
                      </>
                    )}
                  </button>
                  <p className="text-center text-xs text-deep/35 font-body">
                    Replace with{' '}
                    <a href="https://formspree.io" target="_blank" rel="noopener noreferrer" className="text-mid hover:underline">Formspree</a>
                    {' '}or{' '}
                    <a href="https://www.emailjs.com" target="_blank" rel="noopener noreferrer" className="text-mid hover:underline">EmailJS</a>
                    {' '}for real submissions
                  </p>
                </form>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
